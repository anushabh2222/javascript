const v1=10;

 
console.log(v1);

//redeclaration is not allowed and  reassigning the value is not  possible
