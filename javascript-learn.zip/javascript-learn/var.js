var v1=10;
 var  v1=20;
console.log(v1);

//redeclaration is allowed and  reassigning the value is possible
