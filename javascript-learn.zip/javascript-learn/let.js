let v1=10;
 v1=20;
console.log(v1);

//redeclaration is not allowed but reassigning the value is possible

