// function sum(a,b)
// {
//     return(a+b);
// }
// var myv1=[4,5]
// console.log(sum(myv1));                    array is a bunched value


function sum(a,b)
{
    return(a+b);
}
var myv1=[0,5]
console.log(sum(...myv1));           
//    spread operator:spreads bunch of values in to multiple value




